#include "mapsku.h"
#include <QDebug>
#include <QFile>
MapsKU::MapsKU(QWidget* parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);
    //connect(ui.calculate_path, &QPushButton::clicked,this, &MapsKU::addTask);//
    //connect(ui.calculate_path, SIGNAL(clicked()),this, SLOT(MapsKU::addTask) );
    this->data = new QString * [11];
    for (int i = 0; i < 11; i++)
    {
        this->data[i] = new QString[2];
    }
    this->data[0][0] = "Ubit"; data[0][1] = "24.945613, 67.115243";
    this->data[1][0] = "Chemistry Department"; data[1][1] = "24.942762, 67.121296";
    this->data[2][0] = "Mehmood HAssan Library"; data[2][1] = "24.939636, 67.121223";
    this->data[3][0] = "Pharmacy Department"; data[3][1] = "24.944090, 67.115438";
    this->data[4][0] = "Arts"; data[4][1] = "24.937694, 67.119783";
    this->data[5][0] = "IBA"; data[5][1] = "24.940204, 67.115175";
    this->data[6][0] = "Gymnasium Hall"; data[6][1] = "24.937921, 67.118324";
    this->data[7][0] = "Mathematics Department"; data[7][1] = "24.940104, 67.121523";
    this->data[8][0] = "Buisness School"; data[8][1] = "24.938317, 67.111457";
    this->data[9][0] = "Law Department"; data[9][1] = "24.937368, 67.109826";
    this->data[10][0] = "BioChemistry"; data[10][1] = "24.940158, 67.118221";
    for (int i = 0; i < 11; i++)
    {
        ui.source->addItem(data[i][0]);
        ui.destination->addItem(data[i][0]);
    }
}

void MapsKU :: on_calculate_path_clicked()
{
    node_to_node_path(ui.source->currentIndex(), ui.destination->currentIndex(), djikstra(0, adjacencyList, vertices), vertices);

    QString latSource;
    QString lonSource;
    QString latDestination;
    QString lonDestination;
    for (size_t i = 0; i < 10; i++)
    {
        if (data[i][0] == ui.source->currentText()) {
            QStringList pieces = data[i][1].split(",");
            latSource = pieces.value(pieces.length() - 2);
            lonSource = pieces.value(pieces.length() - 1);
        }
        if (data[i][0] == ui.destination->currentText()) {
            QStringList pieces = data[i][1].split(",");
            latDestination = pieces.value(pieces.length() - 2);
            lonDestination = pieces.value(pieces.length() - 1);
        }
    }
    QString text=ui.source->currentText() + ": Lat " + latSource + " Lon " + lonSource + '\n' +
                 ui.destination->currentText() + ": Lat " + latDestination + " Lon " + lonDestination;
    ui.textEdit->setText(text);
}

void MapsKU :: set_adjacencyList() {
    QString data;
    QString fileName(":/new/prefix1/graph.txt");
    QFile file(fileName);
    !file.open(QIODevice::ReadOnly);
    data = file.readAll();
    data= data.replace(" ", "");
    QStringList pieces = data.split("\r\n");
    this->vertices= pieces.value(1).toInt();
    this->adjacencyList = new int* [vertices];
    for (int i = 0; i < vertices; i++)
    {
        this->adjacencyList[i] = new int[vertices];
    }
    for (size_t i = 0; i < vertices; i++)
    {
        for (size_t j = 0; j < vertices; j++)
        {
            adjacencyList[i][j]=0;
        }
    }
    for (size_t i = 2; i < pieces.length(); i++)
    {
        QStringList smaller = pieces.value(i).split(',');
        //qDebug() << "1 " << smaller.value(0) << " 2 " << smaller.value(1) << " 3 " << smaller.value(2);
        this->adjacencyList[smaller.value(0).toInt()][smaller.value(1).toInt()] = smaller.value(2).toInt();
    }
    file.close();
    QDebug dbg(QtDebugMsg);
    for (size_t i = 0; i < vertices; i++)
    {
        for (size_t j = 0; j < vertices; j++)
        {
            dbg << adjacencyList[i][j]<<' ';
        }
        dbg << '\n';
    }
}
int* MapsKU::indegree(int **array,int size) {
    int* IN = new int[size];
    for (int i = 0; i < size; i++)
    {
        int count = 0;
        for (int j = 0; j < size; j++)
        {
            if (array[j][i] != 0)
            {
                count++;
            }
        }
        IN[i] = count;
    }
    /*for (size_t i = 0; i < size; i++)
    {
        qDebug() << IN[i];
    }*/
    return IN;
}
int MapsKU::smallest_array(int* arr, int size, bool* known)
{
    int min;
    for (int i = 0; i < size - 1; i++)
    {
        if (arr[i] < 999999 && known[i] != true)
        {
            min = i;
        }
    }
    return min;
}
void MapsKU::node_to_node_path(int from, int to, int* arr, int size)
{
    int* stack=new int[size];
    int top = to;
    while (top != from)
    {
        s.push(arr[top]);
        top = arr[top];
    }
    while (!s.empty())
    {
        qDebug() << data[s.top()][0] << " ";
        s.pop();
    }
    qDebug() << data[to][0];
}

int* MapsKU::djikstra(int start, int** arr, int size)
{
    int t = 0;
    bool* known=new bool[size];
    int* distance=new int[size];
    int* previous = new int[size];
    previous[start] = -1;
    for (int i = 0; i < size; i++)
    {
        if (i == start)
        {
            known[i] = true;
            distance[i] = 0;
        }
        else
        {
            known[i] = false;
            distance[i] = 9999999;
        }
    }
    while (t < size)
    {
        for (int i = 0; i < size; i++)
        {
            if (arr[start][i] != 0)
            {
                if (distance[i] > distance[start] + arr[start][i])
                {
                    previous[i] = start;
                    distance[i] = distance[start] + arr[start][i];
                }
            }
        }
        start = smallest_array(distance, size, known);
        known[start] = true;
        t++;
    }
    return previous;
}

MapsKU::~MapsKU()
{}