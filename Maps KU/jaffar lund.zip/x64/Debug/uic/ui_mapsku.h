/********************************************************************************
** Form generated from reading UI file 'mapsku.ui'
**
** Created by: Qt User Interface Compiler version 6.4.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAPSKU_H
#define UI_MAPSKU_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MapsKUClass
{
public:
    QWidget *centralWidget;
    QLabel *label;
    QComboBox *source;
    QComboBox *destination;
    QLabel *label_2;
    QPushButton *calculate_path;
    QTextEdit *textEdit;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MapsKUClass)
    {
        if (MapsKUClass->objectName().isEmpty())
            MapsKUClass->setObjectName("MapsKUClass");
        MapsKUClass->resize(564, 400);
        centralWidget = new QWidget(MapsKUClass);
        centralWidget->setObjectName("centralWidget");
        label = new QLabel(centralWidget);
        label->setObjectName("label");
        label->setGeometry(QRect(80, 30, 61, 21));
        source = new QComboBox(centralWidget);
        source->setObjectName("source");
        source->setEnabled(true);
        source->setGeometry(QRect(80, 50, 121, 22));
        source->setCursor(QCursor(Qt::PointingHandCursor));
        destination = new QComboBox(centralWidget);
        destination->setObjectName("destination");
        destination->setGeometry(QRect(310, 50, 121, 22));
        destination->setCursor(QCursor(Qt::PointingHandCursor));
        label_2 = new QLabel(centralWidget);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(310, 30, 71, 16));
        calculate_path = new QPushButton(centralWidget);
        calculate_path->setObjectName("calculate_path");
        calculate_path->setGeometry(QRect(200, 100, 121, 24));
        calculate_path->setCursor(QCursor(Qt::PointingHandCursor));
        textEdit = new QTextEdit(centralWidget);
        textEdit->setObjectName("textEdit");
        textEdit->setGeometry(QRect(120, 180, 241, 71));
        MapsKUClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MapsKUClass);
        menuBar->setObjectName("menuBar");
        menuBar->setGeometry(QRect(0, 0, 564, 22));
        MapsKUClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MapsKUClass);
        mainToolBar->setObjectName("mainToolBar");
        MapsKUClass->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MapsKUClass);
        statusBar->setObjectName("statusBar");
        MapsKUClass->setStatusBar(statusBar);

        retranslateUi(MapsKUClass);

        QMetaObject::connectSlotsByName(MapsKUClass);
    } // setupUi

    void retranslateUi(QMainWindow *MapsKUClass)
    {
        MapsKUClass->setWindowTitle(QCoreApplication::translate("MapsKUClass", "MapsKU", nullptr));
        label->setText(QCoreApplication::translate("MapsKUClass", "Source", nullptr));
        label_2->setText(QCoreApplication::translate("MapsKUClass", "Destination", nullptr));
        calculate_path->setText(QCoreApplication::translate("MapsKUClass", "Calculate", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MapsKUClass: public Ui_MapsKUClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAPSKU_H
